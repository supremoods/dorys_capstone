<div class="event-calendar">
    <div class="wrapper">
        <div id="calendar"></div>
    </div>
</div>