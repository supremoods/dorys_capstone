<div class="main">
    <div class="header">
        <img src="/public/images/logo/dorys_logo.png" alt="" width="48" height="48" />
    </div>

    <div class="signIn">
        Administrator Login
    </div>
    <form id="login-form" method="post">
        <div class="form">
            <label for="login_field">Username</label>
            <input type="text" name="login" id="login_field" tabindex="2" required/>
            <label for="password_field">Password</label>
            <input type="password" name="password" id="login_password" tabindex="2" required/>
            <input type="submit" name="commit" value="Sign In" tabindex="3" class="lastInput" />
        </div>
    </form>

</div>