<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Dory's</title>

    <?php include $_SERVER['DOCUMENT_ROOT'].'/admin/links/header/header_links.php'; ?>
    <link rel="stylesheet" href="/admin/public/css/style.css">

</head>

<body>
    <?php include  $_SERVER['DOCUMENT_ROOT'].'/admin/components/sidebar.php'; ?>

    <?php include  $_SERVER['DOCUMENT_ROOT'].'/admin/components/dashboardCards.php'; ?>

    <?php include  $_SERVER['DOCUMENT_ROOT'].'/admin/links/footer/footer_links.php'; ?>

    <script src="/admin/public/js/script.js"></script>
</body>

</html>