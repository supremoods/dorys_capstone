<div class="check-available-dates">
    <div class="wrapper">
        <div>
            <div class="form-group-container">
                <button id="check-dates-btn" class="submit-btn">Check Available Dates</button>
            </div>
        </div>
    </div>
</div>