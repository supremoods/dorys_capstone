<link rel="stylesheet" href="/public/css/root.css">
<link rel="stylesheet" href="/public/css/header.css">
<link rel="stylesheet" href="/public/css/footer.css">
<link rel="stylesheet" href="/public/css/swiper-bundle.min.css">
<script src="https://kit.fontawesome.com/f9a9e859ec.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="/public/plugins/fullcalendar/lib/main.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.dataTables.css">
<script src="/public/plugins/fullcalendar/lib/main.js"></script>